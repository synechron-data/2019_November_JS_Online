import '../public/favicon.ico';

// import './1_DataTypes/1_Declarations';
// import './1_DataTypes/2_ES6_Declarations';
// import './1_DataTypes/3_ES6_Const';
// import './1_DataTypes/4_DataTypes';

// import './2_Operators/1_Equality';
// import './2_Operators/2_Symbols';
// import './2_Operators/3_Conversion';

// import './3_Functions/1_FnCreation';
// import './3_Functions/2_FnParameters';
// import './3_Functions/3_RestAndSpread';
// import './3_Functions/4_PureAndImpureFn';
// import './3_Functions/5_FnAsParameters';
// import './3_Functions/6_ES6_ArrowFn';
import './3_Functions/7_IIFE';




