// ---------------------- With Premitive

// var a = 1;

// function modify(data) {
//     data = 100;
// }

// console.log("Before - ", a);
// modify(a);
// console.log("After - ", a);

// --------------------------- Complex Type
var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// Impure Function
// function modify(dataArr) {
//     dataArr[0] = 100;
// }

// function modify(dataArr) {
//     var rArr = [...dataArr];
//     rArr[0] = 100;
// }

// Impure 
// function insert(dataArr, x) {
//     dataArr[dataArr.length] = x;
//     return dataArr;
// }

// Pure
function insert(dataArr, x) {
    var rArr = [...dataArr];
    rArr[dataArr.length] = x;
    return rArr;
}

console.log("Before - ", arr);
// modify(arr);
var newArr = insert(arr, 100);
console.log("After - ", arr);

console.log("newArr - ", newArr);