// document.getElementById("b1").addEventListener("click", function(e){
// });

// $(document).ready(function(){
//     $("#b1").click(function(){
//     })
// })

// setInterval(function () {
//     console.log(new Date().toTimeString());
// }, 1000);

// ----------------------------------------------------
// Dev1

// function getString() {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev2
// // console.log(getString());
// setInterval(function () {
//     console.log(getString());
// }, 2000);

// -------------------------------------------------- Push
// Dev1
function getString(cb) {
    const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
    setInterval(function () {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

// Dev2
getString(function (s) {
    console.log(s);
});
