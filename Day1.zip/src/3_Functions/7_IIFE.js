// Immediatly Invoked Function Expression (IIFE)

// function hello() {
//     console.log("Hello World!");
// }

// hello();

// (function () {
//     console.log("Hello World!");
// })();

// (() => {
//     console.log("Hello World!");
// })();

// ------------------------------------

// function hello(name) {
//     console.log("Hello", name);
// }

// hello("Synechron");

// (function (name) {
//     console.log("Hello", name);
// })("Manish");

// ((name) => {
//     console.log("Hello", name);
// })("Abhijeet");

// (name => {
//     console.log("Hello", name);
// })("Ramakant");

// ---------------------------------------

var i = "Hello";
console.log("Before, i is", i);

(function () {
    for (var i = 0; i < 5; i++) {
        console.log("Inside, i is", i);
    }
})();

console.log("After, i is", i);