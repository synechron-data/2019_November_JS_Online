// function hello(name) {
//     if (typeof name != "string")
//         throw Error("Invalid Parameter Type...");

//     console.log("Welcome, ", name);
// }

// try {
//     // hello("Manish");
//     // hello(23);
//     // hello();
//     // hello("Manish", "Pune");
// } catch (err) {
//     console.log(err);
// }

// // hello("Manish");

//------------------------------------- Handling Less Parameters

// function add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;

//     throw Error("Invalid Parameter Type...");
// }

// ES 6 - Default Parameters
// function add(x = 0, y = 0) {
//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;

//     throw Error("Invalid Parameter Type...");
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());

//------------------------------------- Handling Extra Parameters

// function hello(name) {
//     if (typeof name != "string")
//         throw Error("Invalid Parameter Type...");

//     console.log("Welcome, ", name);
//     console.log(arguments);
// }

// hello("Manish");
// hello("Manish", "Pune");
// hello("Manish", "Pune", 411021);

// ES6 - Rest Parameters
// function hello(name, ...args) {
//     if (typeof name != "string")
//         throw Error("Invalid Parameter Type...");

//     console.log("Welcome, ", name);
//     console.log(args);
// }

// hello("Manish");
// hello("Manish", "Pune");
// hello("Manish", "Pune", 411021);

function average(...numbers) {
    console.log(numbers);
    var sum = 0;

    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }

    if (numbers.length)
        return sum / numbers.length;
    else
        return sum;
}

console.log(average());
console.log(average(1));
console.log(average(1, 2));
console.log(average(1, 2, 3, 4, 5));
console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));

var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
console.log(average(...arr));       // Spread Operator

