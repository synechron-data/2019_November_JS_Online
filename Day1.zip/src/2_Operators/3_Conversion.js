var data = prompt("Enter a number");
console.log(data);

var r1 = data + 10;
console.log(r1);

var r2 = parseInt(data) + 10;
console.log(r2);

var r3 = parseFloat(data) + 10;
console.log(r3);

var r4 = Number(data) + 10;
console.log(r4);

var flag = true;
console.log(flag.toString());
console.log(String(flag));
