// const color = "red";

// function test(str) {
//     console.log(str === color);
// }

// const color2 = "red";

// test(color2);
// test("red");

// // ---------------------------------

// const color1 = { color: "red" };
// const color2 = { color: "red" };

// function test(str) {
//     console.log(str === color1);
// }

// test(color2);
// test("red");
// test({ color: "red" });

// --------------------------------- Symbol

const color1 = Symbol("red");
const color2 = Symbol("red");

function test(str) {
    console.log(str === color1);
}

test(color2);
test("red");
test(color1);