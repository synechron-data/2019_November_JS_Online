// const env = "dev";
// console.log(env);

// env = "prod";
// console.log(env);

// ------------------- Block Scoping

// const env = "dev";
// console.log(env);

// if (true) {
//     const env = "prod";
//     console.log(env);
// }

// ------------------------ const with Complex Types

const obj = { id: 1 };
console.log(obj);

obj.id = 100;
// obj = {};
console.log(obj);
