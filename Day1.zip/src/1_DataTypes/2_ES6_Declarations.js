// let a = 10;
// console.log(a);

// It will work only when you compile the code
// let keyword is not hoisted by default
// a = 10;
// console.log("a - ", a);
// let a;

// let a = 10;
// let a = "Hello";

// ES 2015 Scopes
// Global Scope
// Function Scope
// Block Scope - let / const KeyWord
var i = "Hello";
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside, i is", i);
}

console.log("After, i is", i);