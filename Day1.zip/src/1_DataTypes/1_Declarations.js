'use strict'
// console.log("Hello from Declarations File...");

// a = 10;
// console.log("a - ", a);

// var a = 10;
// console.log("a - ", a);

// Hoisting - Hoisting is JavaScript's Runtime default behavior of 
// moving declarations to the top.

// a = 10;
// console.log("a - ", a);
// var a;

// Initializations are not Hoisted
// console.log("a - ", a);
// var a = 10;

// Not Typesafe
// var a = 10;
// a = "Hello";
// console.log("a - ", a);

// var a = 10;
// var a = "Hello";
// console.log("a - ", a);

// var does not give block scoping, 
// Only Global and Function Scope is supports using var keyword

var i = "Hello";
console.log("Before, i is", i);

for (var i = 0; i < 5; i++) {
    console.log("Inside, i is", i);
}
// function Iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside, i is", i);
//     }
// }

// Iterate();

console.log("After, i is", i);