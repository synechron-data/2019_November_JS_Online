var language;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = null;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = 10;
language = 10.5;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = "JavaScript";
// language = 'JavaScript';

// ES6 - Template Literal
// language = `Java

// Script`;

var d1 = "Java";
var d2 = "Script";
// language = d1 + " " + d2;
language = `${d1} ${d2}`;

console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = true;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// ES 6 - Symbol
language = Symbol("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);