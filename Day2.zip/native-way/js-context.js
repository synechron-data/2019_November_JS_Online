function Check() {
    console.log(this);
    console.log("Check Called....");
}

Check();
Check.call();
Check.apply();