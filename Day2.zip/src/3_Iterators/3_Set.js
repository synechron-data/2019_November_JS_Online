// Weak Set
var set = new Set();

// console.log(set);
// console.log(typeof set);
// console.log(set.size);

set.add(1);
set.add(2);
set.add(3);
set.add(4);
set.add(1);
set.add(2);

// console.log(set.size);

for(const item of set){
    console.log(item);
}