// var employees = new Array();
// var employees = new Array(3);

// employees[0] = "ABC";
// employees[1] = "AAA";
// employees[2] = "ABB";
// employees[3] = "CCC";

// var employees = new Array("Manish");
// var employees = ["Manish", "Abhijeet"];
// console.log(employees.length);

var employees = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Neeraj", city: "Delhi" },
    { id: 3, name: "Pravin", city: "Pune" }
];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i} \t ${employees[i].name}`);
// }

// for (const key in employees) {
//     console.log(`${key} \t ${employees[key].name}`);
// }

// ES 2015 - For of Loop
// for (const item of employees) {
//     console.log(`${item.name}`);
// }

// console.log(employees.entries());

for (const [key, value] of employees.entries()) {
    console.log(`${key} ${value.name}`);
}