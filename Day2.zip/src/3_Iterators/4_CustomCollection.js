class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];
    //     }
    // }

    // [Symbol.iterator]() {
    //     const self = this;
    //     let i = 0;

    //     return {
    //         next: function () {
    //             let v, d = true;

    //             if (self._dataArray[i] !== undefined) {
    //                 v = self._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             }
    //         }
    //     };
    // }
}

var numberQ = new Queue();

numberQ.push(10);
numberQ.push(20);
numberQ.push(30);
numberQ.push(40);

for (const item of numberQ) {
    console.log(item);
}

// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());