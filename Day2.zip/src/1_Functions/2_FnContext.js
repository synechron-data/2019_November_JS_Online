// function Check() {
//     console.log(this);
//     console.log("Check Called....");
// }

// // Check();
// // Check.call();
// // Check.apply();

// // Context Switching
// Check.call(window);
// Check.apply(window);

// var nCheck = Check.bind(window);
// nCheck();

// --------------------------------

// function Check(x, y) {
//     console.log(this);
//     console.log("Check Called....");
//     console.log(`x = ${x}, y = ${y}`);
// }

// Check(23, 45);
// Check.call(window, 23, 45);
// Check.apply(window, [23, 45]);

// var nCheck = Check.bind(window, 2, 3);
// nCheck();

// ------------------------------------

// var p1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.display();
// p2.display();

function display() {
    console.log(JSON.stringify(this));
}

var p1 = {
    id: 1,
    name: "Manish",
};

var p2 = {
    id: 2,
    name: "Abhijeet"
};

// display.call(p1);
// display.call(p2);

p1.display = display.bind(p1);
p2.display = display.bind(p2);

// console.log(p1);
// console.log(p2);

p1.display();
p2.display();