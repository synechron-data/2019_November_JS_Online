// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(' km', 1.6, 0, 10));
// console.log(Converter(' km', 1.6, 0, 40));
// console.log(Converter(' km', 1.6, 0, 55));
// console.log(Converter(' km', 1.6, 0, 85));

// ---------------------------------------
// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// var mGreet = greetings.bind(this, "Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

var milesTokm = Converter.bind(this, ' km', 1.6, 0);
console.log(milesTokm(10));
console.log(milesTokm(40));
console.log(milesTokm(55));
console.log(milesTokm(85));

var usdToinr = Converter.bind(this, ' INR', 72, 0);
console.log(usdToinr(100));
console.log(usdToinr(1000));

