// var count = 0;

// function Next() {
//     return count += 1;
// }

// console.log(Next());
// count = "ABC";
// console.log(Next());
// console.log(Next());

// ----------------------------------
// function Next() {
//     var count = 0;
//     return count += 1;
// }

// console.log(Next());
// console.log(Next());
// console.log(Next());

// -----------------------------------

// var getCounter = function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// };

// var Next = getCounter();

// console.log(Next());
// console.log(Next());
// console.log(Next());

// -----------------------------------

// var Next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// console.log(Next());
// console.log(Next());
// console.log(Next());

// -----------------------------------

// var counter = (function () {
//     var count = 0;

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// console.log(counter.next());
// console.log(counter.next());
// console.log(counter.prev());
// console.log(counter.next());

// ---------------------------------------

var getCounter = function (by) {
    var count = 0;

    return {
        next: function () {
            return count += by;
        },
        prev: function () {
            return count -= by;
        }
    };
};

var counter5 = getCounter(5);
console.log(counter5.next());
console.log(counter5.next());

console.log("\n");

var counter15 = getCounter(15);
console.log(counter15.next());
console.log(counter15.next());