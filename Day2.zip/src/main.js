import '../public/favicon.ico';

// import './1_Functions/1_Closure';
// import './1_Functions/2_FnContext';
// import './1_Functions/3_FnCurrying';

// import './2_Types/1_ObjectCreation';
// import './2_Types/2_ObjectType';
// import './2_Types/3_ObjectMethods';
// import './2_Types/4_CustomTypes';
// import './2_Types/5_UsingPrototype';
// import './2_Types/6_ES6_Class';
// import './2_Types/7_ES5_Properties';
// import './2_Types/8_ES6_Properties';
// import './2_Types/9_ES5_Inheritance';
// import './2_Types/10_ES6_Inheritance';
// import './2_Types/11_StaticMembers';

// import './3_Iterators/1_Array';
// import './3_Iterators/2_Map';
// import './3_Iterators/3_Set';
// import './3_Iterators/4_CustomCollection';

// import './4_Promise/1_CreatePromise';
// import './4_Promise/2_ApiCalls';
// import './4_Promise/3_PromiseChaining';

import './5_Modules/usage';












