var promise = new Promise((resolve, reject) => {
    setTimeout(function () {
        // resolve("This is Success Call");
        reject("This is Error Call");
    }, 2000);
});

// promise.then((msg) => {
//     console.log("Success - ", msg);
// }, (eMsg) => {
//     console.error("Error - ", eMsg);
// });

promise.then((msg) => {
    console.log("Success - ", msg);
}).catch((eMsg) => {
    console.error("Error - ", eMsg);
});