class LocalAPI {
    static getAllPosts(successCB, errorCB) {
        fetch('https://jsonplaceholder.typicode.com/posts').then(
            (response) => {
                response.json().then(data => {
                    successCB(data);
                }).catch((err) => {
                    errorCB("Parse Error");
                });
            }).catch((err) => {
                errorCB("Communication Error");
            })
    }

    static getAllPostsUsingPromise() {
        var promise = new Promise((resolve, reject) => {
            fetch('https://jsonplaceholder.typicode.com/posts').then(
            (response) => {
                response.json().then(data => {
                    resolve(data);
                }).catch((err) => {
                    reject("Parse Error");
                });
            }).catch((err) => {
                reject("Communication Error");
            })
        });
        
        return promise;
    }
}

// -----------------

document.getElementById("btnJS").addEventListener("click", () => {
    // LocalAPI.getAllPosts((data) => {
    //     // Code to Dispaly on UI
    //     console.log(data);
    // }, (eMsg) => {
    //     console.error(eMsg);
    // });

    LocalAPI.getAllPostsUsingPromise().then((data) => {
        // Code to Dispaly on UI
        console.log(data);
    }, (eMsg) => {
        console.error(eMsg);
    });
});

// 1. Chaining Promise
// 2.   Promise Methods (All, Race) 