// Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// Case 2 - Multi Exports - Named Exports
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return 'Check Called';
// }

// Case - Default & Named Exports
export default function square(x) {
    return x * x;
}

export function check(x) {
    return 'Check Called';
}
