var toy1 = new Object();
// console.log(toy1);
// console.log(typeof toy1);

// toy1.color = "red";
// console.log(toy1.color);
// console.log(toy1.toString());

// console.log(toy1);

Object.prototype.color = "red";

var toy2 = new Object();

console.log(toy1.color);
console.log(toy2.color);

toy1.color = "blue";

console.log(toy1);
console.log(toy2);

console.log(typeof Object.prototype);