// var obj = null;
// console.log(obj);
// console.log(typeof obj);

// var obj1 = new Object();
// console.log(obj1);
// console.log(typeof obj1);

// var obj2 = {};
// console.log(obj2);
// console.log(typeof obj2);

var person = {
    id: 1,
    name: "Manish",
    address: {
        city: "Pune",
    },
    display: function () {
        console.log(this);
    }
};

// console.log(person);

// var jString = JSON.stringify(person);
// console.log(jString);

// var p1 = JSON.parse(jString);
// console.log(p1);

// var p1 = person;
// var p1 = Object.assign({}, person);      // Shallow Copy
// var p1 = { ...person };      // Shallow Copy
var p1 = JSON.parse(JSON.stringify(person));    // Deep Copy removing all functions

// p1.id = 100;
p1.address.city = "Mumbai";

console.log(person);
console.log(p1);